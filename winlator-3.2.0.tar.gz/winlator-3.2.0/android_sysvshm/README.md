This is the Android SysVSHM used in Winlator based on https://github.com/pelya/android-shmem

## Build dependencies

	$ dpkg --add-architecture armhf
	$ apt install build-essential make cmake g++-arm-linux-gnueabihf